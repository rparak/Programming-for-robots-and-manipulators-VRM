using System;
using UnityEngine;
using Debug = UnityEngine.Debug;

using static Core;

public class Joint_Ctrl : MonoBehaviour
{
    public int index;
    private Vector3 init_joint_orientation = new Vector3(0.0f, 0.0f, 0.0f);

    void Start()
    {
        init_joint_orientation = transform.localEulerAngles;
    }

    void FixedUpdate()
    {
        try
        {
            GlobalVariables.Q_Actual[index] = Mathf.SmoothStep(GlobalVariables.Q_Actual[index], GlobalVariables.Q_Target[index],
                                                               5.0f * Time.deltaTime);

            transform.localEulerAngles = new Vector3(init_joint_orientation[0],
                                                     init_joint_orientation[1],
                                                     init_joint_orientation[2] + GlobalVariables.Q_Actual[index]);

            if (Mathf.Abs(GlobalVariables.Q_Target[index] - GlobalVariables.Q_Actual[index]) < 1.0f)
            {
                GlobalVariables.Q_In_Pos[index] = true;
            }
            else
            {
                GlobalVariables.Q_In_Pos[index] = false;
            }
        }
        catch (Exception e)
        {
            Debug.Log("Exception:" + e);
        }
    }
    void OnApplicationQuit()
    {
        try
        {
            Destroy(this);
        }
        catch (Exception e)
        {
            Debug.LogException(e);
        }
    }
}