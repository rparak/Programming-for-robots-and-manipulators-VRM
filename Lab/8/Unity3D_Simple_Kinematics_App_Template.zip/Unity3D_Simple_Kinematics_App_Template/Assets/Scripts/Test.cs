using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour
{
    public float v;
    void Start()
    {
        
    }
    void Update()
    {
        transform.Rotate(v * Time.deltaTime, v * Time.deltaTime, v * Time.deltaTime);
    }
}
